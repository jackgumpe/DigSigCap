# Digital Signal Capture System (Windows)

## Setup Instructions

1. **Clone repository**:
```cmd
git clone https://github.com/yourusername/DigitalSignalCapture.git
cd DigitalSignalCapture

2. Setup environment
setup.bat

3. Activate virtual environment
.\.venv\Scripts\activate

4. Run the application:
python main.py