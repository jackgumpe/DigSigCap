
1. Capture all conversations
2. Filter noise & PII
3. Extract metrics
4. Score quality
5. Generate:
   - Pretraining Parquet
   - Finetuning JSONL
   - RLHF preference pairs
