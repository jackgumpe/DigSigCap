
- SHL: Internal shorthand language
- TOON: Structured token-efficient encoding
- Recursive summarization
- Delta encoding
- Token budgets per tier
